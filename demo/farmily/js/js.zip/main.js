$(function(){
	$('.contact-button, .bottomContact, .contact-open, .gridContact').click(function(){
		$('.contact-wrap').addClass('show');
    });
	$('.contact-bg, .contact').click(function(){
		$('.contact-wrap').removeClass('show');
		$('.mq-nav').removeClass('visible');
    });
	$('.menu').click(function() {
        $('.mq-nav').addClass('visible');
    });
	$('.mq-close').click(function() {
            $('.mq-nav').removeClass('visible');
    }); 
	$('.social').click(function() {
            $('.social-wrap').addClass('show');
    });
	$('.socialOverlay').click(function() {
            $('.social-wrap').removeClass('show');
    });  
	if (!Modernizr.svg) {
    $('img[src$=".svg"]').each(function()
    {
        $(this).attr('src', $(this).attr('src').replace('.svg', '.png'));
    });
	}
	$('.post').addClass('transparent').viewportChecker({
        classToAdd: 'visible animated',
        offset: 50
       });
});
function scrollToAnchor(aid){
    var aTag = $("a[id='"+ aid +"']");
    $('html,body').animate({scrollTop: aTag.offset().top - 10},'slow');
	}
		$("#brandingLink, #brandingLink2").click(function() {
   		scrollToAnchor('branding');
	});
		$("#webservicesLink, #webservicesLink2").click(function() {
   		scrollToAnchor('webservices');
	});
		$("#otherLink, #otherLink2, #print, #content").click(function() {
   		scrollToAnchor('other');
	});

	